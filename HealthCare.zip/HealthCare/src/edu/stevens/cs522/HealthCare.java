package edu.stevens.cs522;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

import com.google.android.c2dm.C2DMessaging;

import edu.stevens.cs522.UI.PatientsViewer;
import edu.stevens.cs522.sqs.ClientManager;
import edu.stevens.cs522.sqs.util.SqsQueueList;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class HealthCare extends Activity {
	/** Called when the activity is first created. */
	private static final String TAG = "HealthCare";
	public static final String SENDER_ID = "liwenbin420@gmail.com";
	public static final String MESSAGE_KEY_ONE = "msg";
	public static ClientManager clientManager;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		Log.v(TAG, "Start");

		C2DMessaging.register(this, SENDER_ID);
		clientManager = new ClientManager();

		startActivity(new Intent(getApplicationContext(), PatientsViewer.class));

		TextView v = (TextView) findViewById(R.id.textview);

		OnClickListener l = new OnClickListener() {

			public void onClick(View arg0) {

				startActivity(new Intent(getApplicationContext(),
						PatientsViewer.class));

			}
		};
		v.setOnClickListener(l);

	}

}