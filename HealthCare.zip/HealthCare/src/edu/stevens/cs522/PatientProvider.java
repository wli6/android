 

package edu.stevens.cs522;

import java.util.HashMap;
 
import android.content.ContentProvider;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteQueryBuilder;
import android.net.Uri;
import android.text.TextUtils;
import android.util.Log;

public class PatientProvider extends ContentProvider {
	
	private static final String DATABASE_NAME = "patients.db";
	private static final int DATABASE_VERSION = 1;
	private static final String LOCATION_TABLE_NAME = "location";
	
	private static HashMap<String, String> locationProjectionMap;
	
	private static final int PATIENTS = 1;
	private static final int PATIENT_ID = 2;
	
	private static final UriMatcher uriMatcher;
	
	/**
	 * helper class to open, create, and upgrade the database file
	 */
	private static class DatabaseHelper extends SQLiteOpenHelper {
		DatabaseHelper(Context context) {
			super(context, DATABASE_NAME, null, DATABASE_VERSION);
		}
		
		@Override
		public void onCreate(SQLiteDatabase db) {
			db.execSQL("CREATE TABLE " + LOCATION_TABLE_NAME + " ("
					+ PatientContent.Location._ID + " INTEGER PRIMARY KEY,"
					+ PatientContent.Location.ID + " TEXT,"
					+ PatientContent.Location.NAME + " TEXT,"
					+ PatientContent.Location.TOBEVISITED + " BOOLEAN,"
					+ PatientContent.Location.LATITUDE + " FLOAT,"
					+ PatientContent.Location.LONGITUDE + " FLOAT,"
					+ PatientContent.Location.ADDRESS + " TEXT"
					+ ");");
		}
		
		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
			Log.w("PATIENY_ON_UPGRADE", "Upgrading database from version " + oldVersion
					+ " to " + newVersion + ", which will destroy all old data");
			db.execSQL("DROP TABLE IF EXISTS " + LOCATION_TABLE_NAME);
			onCreate(db);
		}
	}
	
	private DatabaseHelper openHelper;

	@Override
	public boolean onCreate() {
		openHelper = new DatabaseHelper(getContext());
		return true;
	}
	
	@Override
	public Cursor query(Uri uri, String[] projection, String selection,
			String[] selectionArgs, String sortOrder) {
		SQLiteQueryBuilder qb = new SQLiteQueryBuilder();
		
		switch (uriMatcher.match(uri)) {
		case PATIENTS:
			qb.setTables(LOCATION_TABLE_NAME);
			qb.setProjectionMap(locationProjectionMap);
			break;
			
		case PATIENT_ID:
			qb.setTables(LOCATION_TABLE_NAME);
			qb.setProjectionMap(locationProjectionMap);
			qb.appendWhere(PatientContent.Location._ID + "=" + uri.getPathSegments().get(1));
			break;
			
		default:
			throw new IllegalArgumentException("Unknown URI " + uri);
		}
		
		// Use default sort order if not specified
		String orderBy;
		if (TextUtils.isEmpty(sortOrder)) {
			orderBy = PatientContent.Location.DEFAULT_SORT_ORDER;
		} else {
			orderBy = sortOrder;
		}
	
		// Query the database
		SQLiteDatabase db = openHelper.getReadableDatabase();
		Cursor c = qb.query(db, projection, selection, selectionArgs, null, null, orderBy);
		
		// Tell the cursor what uri to watch (for data changes)
		c.setNotificationUri(getContext().getContentResolver(), uri);
		return c;
	}

	@Override
	public String getType(Uri uri) {
		switch (uriMatcher.match(uri)) {
		case PATIENTS:
			return PatientContent.Location.CONTENT_TYPE;
			
		case PATIENT_ID:
			return PatientContent.Location.CONTENT_ITEM_TYPE;
			
		default:
			throw new IllegalArgumentException("Unknown URI " + uri);
		}
	}
	
	@Override
	public Uri insert(Uri uri, ContentValues initialValues) {
		if (uriMatcher.match(uri) != PATIENTS) {
			throw new IllegalArgumentException("Unknown URI " + uri);
		}
	
		ContentValues values;
		if (initialValues != null) {
			values = new ContentValues(initialValues);
		} else {
			values = new ContentValues();
		}
		
		// Make sure fields are set
		if (values.containsKey(PatientContent.Location.ID) == false) {
			values.put(PatientContent.Location.ID, "Unknown");
		}
		
		if (values.containsKey(PatientContent.Location.NAME) == false) {
			values.put(PatientContent.Location.NAME, "Unknown");
		}
		
		if (values.containsKey(PatientContent.Location.TOBEVISITED) == false) {
			values.put(PatientContent.Location.TOBEVISITED, true);
		}

		if (values.containsKey(PatientContent.Location.LATITUDE) == false) {
			values.put(PatientContent.Location.LATITUDE, 0.0);
		}
		
		if (values.containsKey(PatientContent.Location.LONGITUDE) == false) {
			values.put(PatientContent.Location.LONGITUDE, 0.0);
		}
		
		if (values.containsKey(PatientContent.Location.ADDRESS) == false) {
			values.put(PatientContent.Location.ADDRESS, "Unknown");
		}
		
		SQLiteDatabase db = openHelper.getWritableDatabase();
		long rowId = db.insert(LOCATION_TABLE_NAME, PatientContent.Location.ADDRESS, values);
		if (rowId > 0) {
			Uri patientUri = ContentUris.withAppendedId(PatientContent.Location.CONTENT_URI, rowId);
			getContext().getContentResolver().notifyChange(patientUri, null);
			return patientUri;
		}
	
		throw new SQLException("Failed to insert row into " + uri);
	}

	@Override
	public int delete(Uri uri, String selection, String[] selectionArgs) {
		SQLiteDatabase db = openHelper.getWritableDatabase();
		int count;
		switch (uriMatcher.match(uri)) {
		case PATIENTS:
			count = db.delete(LOCATION_TABLE_NAME, selection, selectionArgs);
			break;
			
		case PATIENT_ID: 
			String id = uri.getPathSegments().get(1);
			count = db.delete(LOCATION_TABLE_NAME, PatientContent.Location._ID
					+ "=" + id + (!TextUtils.isEmpty(selection) ? " AND (" 
							+ selection + ")" : ""), selectionArgs);
			break;
		default:
			throw new IllegalArgumentException("Unknown URI " + uri);
		}
	
		getContext().getContentResolver().notifyChange(uri, null);
		return count;
	}

	@Override
	public int update(Uri uri, ContentValues values, String selection,
			String[] selectionArgs) {
		SQLiteDatabase db = openHelper.getWritableDatabase();
	
		int count;
		switch (uriMatcher.match(uri)) {
		case PATIENTS:
			count = db.update(LOCATION_TABLE_NAME, values, selection, selectionArgs);
			break;
			
		case PATIENT_ID:
			String id = uri.getPathSegments().get(1);
			count = db.update(LOCATION_TABLE_NAME, values, PatientContent.Location._ID
					+ "=" + id + (!TextUtils.isEmpty(selection) ? " AND (" 
							+ selection + ")" : ""), selectionArgs);
			break;

		default:
			throw new IllegalArgumentException("Unknown URI " + uri);
		}
		
		getContext().getContentResolver().notifyChange(uri, null);
		return count;
	}
	
	static {
		uriMatcher = new UriMatcher(UriMatcher.NO_MATCH);
		uriMatcher.addURI(PatientContent.AUTHORITY, "location", PATIENTS);
		uriMatcher.addURI(PatientContent.AUTHORITY, "location/#", PATIENT_ID);
		
		locationProjectionMap = new HashMap<String, String>();
		locationProjectionMap.put(PatientContent.Location._ID, PatientContent.Location._ID);
		locationProjectionMap.put(PatientContent.Location.ID, PatientContent.Location.ID);
		locationProjectionMap.put(PatientContent.Location.NAME, PatientContent.Location.NAME);
		locationProjectionMap.put(PatientContent.Location.TOBEVISITED, PatientContent.Location.TOBEVISITED);
		locationProjectionMap.put(PatientContent.Location.LATITUDE, PatientContent.Location.LATITUDE);
		locationProjectionMap.put(PatientContent.Location.LONGITUDE, PatientContent.Location.LONGITUDE);
		locationProjectionMap.put(PatientContent.Location.ADDRESS, PatientContent.Location.ADDRESS);
	}

}
