package edu.stevens.cs522;

import java.io.IOException;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.google.android.c2dm.C2DMBaseReceiver;

import edu.stevens.cs522.UI.PatientsViewer;

public class C2DMReceiver extends C2DMBaseReceiver {
	/*
	 * registrationId = APA91bEeOxpB4SfyJEgh2u9o-
	 * EVsP0Zw3wwUXmuttAC2o7WKSVXtsb_hDSw500ty1Y3XWOpAFt8lpB6lxl5LD2mcv8nOV13dJ1_y1
	 * -SLk1DgcGifjI9lunzWi0C93-PYnpYVTbfbvAc2, error = null, removed = null
	 */
	private static final String TAG = "C2DMReceiver";

	//
	public C2DMReceiver() {
		super(HealthCare.SENDER_ID);
	}

	public C2DMReceiver(String senderId) {
		super(senderId);
		// TODO Auto-generated constructor stub
	}

	// 鎺ユ敹鍒癙ush娑堟伅鐨勫洖璋冨嚱鏁�? @Override
	protected void onMessage(Context context, Intent intent) {
		// TODO Auto-generated method stub
		Log.v(TAG, "C2DMReceiver message");
		Bundle extras = intent.getExtras();
		if (extras != null) {
			String msg = (String) extras.get("payload");

			Log.v(TAG, "The received msg = " + msg);
			Toast.makeText(context, msg, Toast.LENGTH_LONG).show();
			NotificationManager notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
			Notification notification = new Notification(R.drawable.icon, msg,
					System.currentTimeMillis());
			intent = new Intent(this, PatientsViewer.class);
			
			  Bundle bundle = new Bundle();
		        bundle.putString("PatientID", msg);

			intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);// ���д������������
			intent.addFlags(Intent.FILL_IN_DATA);
			intent.putExtras(bundle);
			PendingIntent contentIntent = PendingIntent.getActivity(this, 0,
					intent, 0);
			notification.setLatestEventInfo(this, getString(R.string.app_name),
					msg, contentIntent);
			notification.flags |= Notification.FLAG_AUTO_CANCEL;

			notificationManager.notify(1, notification);

		}
	}

	@Override
	public void onError(Context context, String errorId) {
		// TODO Auto-generated method stub
		Log.v(TAG, "C2DMReceiver error");
	}

	@Override
	public void onRegistered(Context context, String registrationId)
			throws IOException {
		// TODO Auto-generated method stub
		super.onRegistered(context, registrationId);
		Log.v(TAG, "C2DMReceiver Register");
	}

	@Override
	public void onUnregistered(Context context) {
		// TODO Auto-generated method stub
		super.onUnregistered(context);
		Log.v(TAG, "C2DMReceiver UnRegister");
	}
}
