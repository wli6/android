/*********************************************************************

    File          : MarkerOverlay.java
    Author(s)     : enck
    Description   : description

    Copyright (c) 2008 The Pennsylvania State University
    Systems and Internet Infrastructure Security Laboratory

**********************************************************************/

package edu.stevens.cs522;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.SystemClock;
import android.provider.Contacts;
import android.widget.Toast;

import com.google.android.maps.GeoPoint;
import com.google.android.maps.ItemizedOverlay;
import com.google.android.maps.MapView;
import com.google.android.maps.OverlayItem;

public class MarkerOverlay extends ItemizedOverlay<OverlayItem> {

	private Context mContext;
	private List<OverlayItem> itemList = new ArrayList<OverlayItem>();
	private List<Long> idList = new ArrayList<Long>();
	private Drawable dmarker;
	
	private Integer lastIndex;
	private Long mLastTap;
	
	/**
	 * @param defaultMarker
	 */
	public MarkerOverlay(Context c, Drawable m) {
		super(m);
		mContext = c;
		dmarker = m;
	}
	
	public void addMarker(GeoPoint position, String title, String snippet, Long id) {
		itemList.add(new OverlayItem(position, title, snippet));
		idList.add(id);
		populate();
	}

	/* (non-Javadoc)
	 * @see com.google.android.maps.ItemizedOverlay#createItem(int)
	 */
	@Override
	protected OverlayItem createItem(int i) {
		return itemList.get(i);
	}

	/* (non-Javadoc)
	 * @see com.google.android.maps.ItemizedOverlay#onTap(int)
	 */
	@Override
	protected boolean onTap(int index) {
		boolean rc = super.onTap(index);

		boolean show = true;
		long curtime = SystemClock.elapsedRealtime();
		if (lastIndex != null) {
			long diff = curtime - mLastTap;
			// TODO: double click is hardcoded as half a second, make variable
			if (lastIndex == index && diff < 500) {
				lastIndex = null;
				mLastTap = null;
				show = false;
				showContact(idList.get(index));
			} else {
				lastIndex = index;
				mLastTap = curtime;
			}
		} else {
			lastIndex = index;
			mLastTap = curtime;
		}
		
		if (show) {
			String nick = itemList.get(index).getSnippet();
			Toast.makeText(mContext, nick, Toast.LENGTH_SHORT).show();
		}
		
		return rc;
	}

	/* (non-Javadoc)
	 * @see com.google.android.maps.ItemizedOverlay#draw(android.graphics.Canvas, com.google.android.maps.MapView, boolean)
	 */
	@Override
	public void draw(Canvas canvas, MapView mapView, boolean shadow) {
		super.draw(canvas, mapView, shadow);
		
		boundCenterBottom(dmarker);
	}

	/* (non-Javadoc)
	 * @see com.google.android.maps.ItemizedOverlay#size()
	 */
	@Override
	public int size() {
		return itemList.size();
	}
	
	private void showContact(Long id) {
		Intent i = new Intent(Intent.ACTION_VIEW);
		i.setData(Uri.withAppendedPath(Contacts.People.CONTENT_URI, id.toString()));
		mContext.startActivity(i);
	}

}
