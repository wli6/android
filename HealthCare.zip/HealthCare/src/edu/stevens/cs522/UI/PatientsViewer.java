package edu.stevens.cs522.UI;

import java.util.ArrayList;

import com.google.android.c2dm.C2DMessaging;

import android.app.AlertDialog;
import android.app.ListActivity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnCreateContextMenuListener;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import edu.stevens.cs522.HealthCare;
import edu.stevens.cs522.HealthCareUtils;
import edu.stevens.cs522.Patient;
import edu.stevens.cs522.PatientContent;
import edu.stevens.cs522.PatientProvider;
import edu.stevens.cs522.R;
import edu.stevens.cs522.sqs.ClientManager;
import edu.stevens.cs522.sqs.util.SqsQueueList;

public class PatientsViewer extends ListActivity {
	public static final String TAG = "PatientViewer";

	String[] projection = new String[] { PatientContent.Location._ID,
			PatientContent.Location.NAME, PatientContent.Location.ADDRESS,
			PatientContent.Location.LATITUDE,
			PatientContent.Location.LONGITUDE,
			PatientContent.Location.TOBEVISITED

	};

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.patient_list);

		Intent i = getIntent();
		Bundle extras = (i == null) ? null : i.getExtras();
		String patientId = (extras == null) ? null : extras
				.getString("PatientID");

		if (patientId != null) {

			// todo get patient info from web server
 			Patient patient = HealthCareUtils.getPatient(patientId);
			
	 
			if (patient != null) {

				ContentValues values = new ContentValues();
				values.put(PatientContent.Location.ID, patient.getId());
				values.put(PatientContent.Location.ADDRESS,
						patient.getAddress());
				values.put(PatientContent.Location.LATITUDE,
						patient.getLatitude());
				values.put(PatientContent.Location.LONGITUDE,
						patient.getLongitude());
				values.put(PatientContent.Location.NAME, patient.getName());
				values.put(PatientContent.Location.TOBEVISITED, true);

			 
				ContentResolver r = PatientsViewer.this.getContentResolver();
				Uri uri = r.insert(PatientContent.Location.CONTENT_URI, values);

			}
		}

		populate();

		this.getListView().setOnCreateContextMenuListener(
				new OnCreateContextMenuListener() {

					public void onCreateContextMenu(ContextMenu menu, View v,
							ContextMenuInfo menuInfo) {
						if (v.getId() == android.R.id.list) {
							menu.setHeaderTitle("Operation");
							String[] menuItems = getResources().getStringArray(
									R.array.menu_array);
							for (int i = 0; i < menuItems.length; i++) {
								menu.add(Menu.NONE, i, i, menuItems[i]);
							}
						}
					}

				});
		
		
		Button button  = (Button) this.findViewById(R.id.button1);
		button.setOnClickListener(new View.OnClickListener() {
				public void onClick(View arg0) {
					
					if (HealthCare.clientManager.hasCredentials()) {
						startActivity(new Intent(PatientsViewer.this, SqsQueueList.class));
					} else {					
						displayCredentialsIssueAndExit();					
					}
				}
			});
		
		Button button1  = (Button) this.findViewById(R.id.button2);
		button1.setOnClickListener(new View.OnClickListener() {
				public void onClick(View arg0) {
					 
					ArrayList<Patient> patients = HealthCareUtils.getAllPatients(); 
					if ((patients == null) || (patients.size() == 0))
						return;
					for (Patient patient:patients){
						ContentValues values = new ContentValues();
						values.put(PatientContent.Location.ID, patient.getId());
						values.put(PatientContent.Location.ADDRESS,
								patient.getAddress());
						values.put(PatientContent.Location.LATITUDE,
								patient.getLatitude());
						values.put(PatientContent.Location.LONGITUDE,
								patient.getLongitude());
						values.put(PatientContent.Location.NAME, patient.getName());
						values.put(PatientContent.Location.TOBEVISITED, true);

					 
						ContentResolver cr = PatientsViewer.this.getContentResolver();
						Uri uri = cr.insert(PatientContent.Location.CONTENT_URI, values);
					}
					
				}
			});
		
		
		
		
		Button button4  = (Button) this.findViewById(R.id.button4);
		button4.setOnClickListener(new View.OnClickListener() {
				public void onClick(View arg0) {
					ContentResolver r = PatientsViewer.this.getContentResolver();
					r.delete(PatientContent.Location.CONTENT_URI, null, null);
					
					
					
				}
			});
		
		
		Button button2  = (Button) this.findViewById(R.id.button3);
		button2.setOnClickListener(new View.OnClickListener() {
				public void onClick(View arg0) {
					ContentValues values = new ContentValues();
					values.put(PatientContent.Location.ID, "123");
					values.put(PatientContent.Location.ADDRESS,
							"hoboken");
					values.put(PatientContent.Location.LATITUDE,
							40);
					values.put(PatientContent.Location.LONGITUDE,
							-70);
					values.put(PatientContent.Location.NAME, "ly");
					values.put(PatientContent.Location.TOBEVISITED, true);

				 
					ContentResolver r = PatientsViewer.this.getContentResolver();
					Uri uri = r.insert(PatientContent.Location.CONTENT_URI, values);
				}
			});
		
		
	

	}
	
    protected void displayCredentialsIssueAndExit() {
        AlertDialog.Builder confirm = new AlertDialog.Builder( this );
        confirm.setTitle("Credential Problem!");
        confirm.setMessage( "AWS Credentials not configured correctly.  Please review the README file." );
        confirm.setNegativeButton( "OK", new DialogInterface.OnClickListener() {
            public void onClick( DialogInterface dialog, int which ) {
            	PatientsViewer.this.finish();
            }
        } );
        confirm.show().show();                
    }

	@Override
	public boolean onContextItemSelected(MenuItem item) {
		AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item
				.getMenuInfo();
		ContentValues values = new ContentValues();

		values.put(PatientContent.Location.TOBEVISITED, false);

		String where = PatientContent.Location._ID + "=?";
		this.getApplicationContext()
				.getContentResolver()
				.update(PatientContent.Location.CONTENT_URI, values, where,
						new String[] { String.valueOf(info.id) });

		return true;
	}

	private void populate() {

		Cursor c = managedQuery(PatientContent.Location.CONTENT_URI,
				projection, null, null, null);

		ListAdapter adapter = new SimpleCursorAdapter(this,
				R.layout.patient_row, c, new String[] {
						PatientContent.Location.NAME,
						PatientContent.Location.ADDRESS,
						PatientContent.Location.LATITUDE,
						PatientContent.Location.LONGITUDE,
						PatientContent.Location.TOBEVISITED }, new int[] {
						R.id.patient_name, R.id.patient_address,
						R.id.patient_latitude, R.id.patient_longitude,
						R.id.patient_tobevisited });
		setListAdapter(adapter);

	}

	@Override
	protected void onListItemClick(ListView l, View v, int position, long id) {
		super.onListItemClick(l, v, position, id);

		Intent i = new Intent(this, PatientsMap.class);
		i.putExtra("patient_id", id);
		startActivity(i);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		boolean rc = super.onCreateOptionsMenu(menu);

		menu.add(0, Menu.FIRST, 0, "View Map");
		menu.add(0, Menu.FIRST + 1, 0, "View See");
		menu.add(0, Menu.FIRST + 2, 0, "View To Be See");
		menu.add(0, Menu.FIRST + 3, 0, "View All");
		return rc;
	}

	@Override
	public boolean onMenuItemSelected(int featureId, MenuItem item) {
		Intent i;
		switch (item.getItemId()) {
		case Menu.FIRST:
			i = new Intent(this, PatientsMap.class);
			startActivity(i);
			break;
		case Menu.FIRST + 1:
			Cursor c1 = managedQuery(PatientContent.Location.CONTENT_URI,
					projection, PatientContent.Location.TOBEVISITED + "=0",
					null, null);

			ListAdapter adapter1 = new SimpleCursorAdapter(this,
					R.layout.patient_row, c1, new String[] {
							PatientContent.Location.NAME,
							PatientContent.Location.ADDRESS,
							PatientContent.Location.LATITUDE,
							PatientContent.Location.LONGITUDE,
							PatientContent.Location.TOBEVISITED }, new int[] {
							R.id.patient_name, R.id.patient_address,
							R.id.patient_latitude, R.id.patient_longitude,
							R.id.patient_tobevisited });

			setListAdapter(adapter1);
			break;
		case Menu.FIRST + 2:
			Cursor c2 = managedQuery(PatientContent.Location.CONTENT_URI,
					projection, PatientContent.Location.TOBEVISITED
							+ "=1", null, null);

			ListAdapter adapter2 = new SimpleCursorAdapter(this,
					R.layout.patient_row, c2, new String[] {
							PatientContent.Location.NAME,
							PatientContent.Location.ADDRESS,
							PatientContent.Location.LATITUDE,
							PatientContent.Location.LONGITUDE,
							PatientContent.Location.TOBEVISITED }, new int[] {
							R.id.patient_name, R.id.patient_address,
							R.id.patient_latitude, R.id.patient_longitude,
							R.id.patient_tobevisited });
			setListAdapter(adapter2);
			break;
		case Menu.FIRST + 3:
			Cursor c3 = managedQuery(PatientContent.Location.CONTENT_URI,
					projection, null, null, null);

			ListAdapter adapter3 = new SimpleCursorAdapter(this,
					R.layout.patient_row, c3, new String[] {
							PatientContent.Location.NAME,
							PatientContent.Location.ADDRESS,
							PatientContent.Location.LATITUDE,
							PatientContent.Location.LONGITUDE,
							PatientContent.Location.TOBEVISITED }, new int[] {
							R.id.patient_name, R.id.patient_address,
							R.id.patient_latitude, R.id.patient_longitude,
							R.id.patient_tobevisited });
			setListAdapter(adapter3);
			break;
		}

		return super.onMenuItemSelected(featureId, item);
	}

}