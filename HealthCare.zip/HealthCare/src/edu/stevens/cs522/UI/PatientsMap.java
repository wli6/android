package edu.stevens.cs522.UI;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.drawable.Drawable;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.SimpleCursorAdapter;

import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapActivity;
import com.google.android.maps.MapController;
import com.google.android.maps.MapView;
import com.google.android.maps.MyLocationOverlay;

import edu.stevens.cs522.MarkerOverlay;
import edu.stevens.cs522.PatientContent;
import edu.stevens.cs522.R;
import edu.stevens.cs522.R.drawable;
import edu.stevens.cs522.R.id;
import edu.stevens.cs522.R.layout;


/**
 * @author enck
 *
 */
public class PatientsMap extends MapActivity {
	
	private Long patientId;
	private MapView map;
	private MapController mapCtl;
	
	//private TextView locLabel;
	//private TextView locValue;
	private LinearLayout zoomCtl;
	private MarkerOverlay markers;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.map);
		
		// Link to GUI
		//locLabel = (TextView) findViewById(R.id.location_label);
		//locValue = (TextView) findViewById(R.id.location_value);
		setupMap();
		
		
		
		Intent i = getIntent();
		Bundle extras = (i == null) ? null : i.getExtras();
		patientId = (extras == null) ? null : extras.getLong("patient_id");
	
		if (patientId != null) {
			Cursor c = managedQuery(PatientContent.Location.CONTENT_URI, null, 
					PatientContent.Location._ID+"="+patientId, null, null);
			if (c.moveToFirst()) {
				displayPatient(c);
			}
		} else {
			Cursor c = managedQuery(PatientContent.Location.CONTENT_URI, null, 
					null, null, null);
			if (c.moveToFirst()) do {
				displayPatient(c);
			} while (c.moveToNext());
		}
		
//		initMyLocation();
	}
	
	  /** Start tracking the position on the map. */  
	   private void initMyLocation() {  
	      final MyLocationOverlay overlay = new MyLocationOverlay(this, map);//�ṩ����ͼ  
	      overlay.enableMyLocation(); //��������λ�õĸ���  
	      //overlay.enableCompass(); // ��������ָ����ĸ���  
//	      overlay.runOnFirstFix(new Runnable() {//�ø���ͼ��һ��ִ�еĲ���  
//	         public void run() {  
	            // Zoom in to current location  
	        	 mapCtl.setZoom(8);//���ż���8  
	        //    mapCtl.animateTo(overlay.getMyLocation());//���Ŷ���������ͼ��������ָ��λ���Ƶ������ڵ�λ��  
//	         }  
//	      });  
	      map.getOverlays().add(overlay);  
	   }  
	
	private void setupMap() {
		map = (MapView) findViewById(R.id.map_view);
		zoomCtl = (LinearLayout) findViewById(R.id.map_zoom);
		
		map.displayZoomControls(true);
		map.setClickable(true);
		map.setEnabled(true);
		mapCtl = map.getController();
		View zoomView = map.getZoomControls();
		zoomCtl.addView(zoomView,
				new ViewGroup.LayoutParams(LayoutParams.WRAP_CONTENT, 
						LayoutParams.WRAP_CONTENT));
	
		// Setup the markers
		Drawable marker = getResources().getDrawable(R.drawable.bubble);
		marker.setBounds(0,0, (int)(marker.getIntrinsicWidth()),
				(int)(marker.getIntrinsicHeight()));
		
		markers = new MarkerOverlay(this, marker);
		map.getOverlays().add(markers);
	}
	
	private void displayPatient(Cursor c) {
		Long contact_id = getContactId(c);
		String nick = getNick(c);
		Location loc = getLocation(c);
		
		int lat = (int)(loc.getLatitude()*1000000);
		int lon = (int)(loc.getLongitude()*1000000);
		GeoPoint center = new GeoPoint(lat,lon);

		mapCtl.setCenter(center);
		mapCtl.setZoom(15);
	
		markers.addMarker(center, nick, nick, contact_id);
	}

	private Long getContactId(Cursor c) {
		return c.getLong(c.getColumnIndex(PatientContent.Location.ID));
	}
	private String getNick(Cursor c) {
		return c.getString(c.getColumnIndex(PatientContent.Location.NAME));
	}
	
	private Location getLocation(Cursor c) {
		double lat = c.getDouble(c.getColumnIndex(PatientContent.Location.LATITUDE));
		double lon = c.getDouble(c.getColumnIndex(PatientContent.Location.LONGITUDE));
		
		Location floc = new Location(LocationManager.GPS_PROVIDER);
		floc.setLatitude(lat);
		floc.setLongitude(lon);
		
		return floc;
	}

	/* (non-Javadoc)
	 * @see com.google.android.maps.MapActivity#isRouteDisplayed()
	 */
	@Override
	protected boolean isRouteDisplayed() {
		// TODO Auto-generated method stub
		return false;
	}

	/* (non-Javadoc)
	 * @see com.google.android.maps.MapActivity#isLocationDisplayed()
	 */
	@Override
	protected boolean isLocationDisplayed() {
		// TODO Auto-generated method stub
		return super.isLocationDisplayed();
		//return true;
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		boolean rc = super.onCreateOptionsMenu(menu);

		menu.add(0, Menu.FIRST, 0, "View All");
		menu.add(0, Menu.FIRST + 1, 0, "View See");
		menu.add(0, Menu.FIRST + 2, 0, "View To Be See");
		return rc;
	}
	
	public boolean onMenuItemSelected(int featureId, MenuItem item) {
		Intent i;
		switch (item.getItemId()) {
		case Menu.FIRST:
			i = new Intent(this, PatientsMap.class);
			startActivity(i);
			break;
		case Menu.FIRST + 1:
			Cursor c = managedQuery(PatientContent.Location.CONTENT_URI, null, 
					null, null, null);
			if (c.moveToFirst()) {
				displayPatient(c);
			}
			break;
		case Menu.FIRST + 2:
			Cursor c1 = managedQuery(PatientContent.Location.CONTENT_URI, null, 
					PatientContent.Location.TOBEVISITED+"=0", null, null);
			if (c1.moveToFirst()) {
				displayPatient(c1);
			}
			break;
		case Menu.FIRST + 3:
			Cursor c2 = managedQuery(PatientContent.Location.CONTENT_URI, null, 
					PatientContent.Location.TOBEVISITED+"=1", null, null);
			if (c2.moveToFirst()) {
				displayPatient(c2);
			}
			break;			
		}

		return super.onMenuItemSelected(featureId, item);
	}


}
