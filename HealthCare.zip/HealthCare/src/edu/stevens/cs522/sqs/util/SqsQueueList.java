/*
 * Copyright 2010-2012 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 *
 *  http://aws.amazon.com/apache2.0
 *
 * or in the "license" file accompanying this file. This file is distributed
 * on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */
package edu.stevens.cs522.sqs.util;

import java.util.ArrayList;
import java.util.List;

import edu.stevens.cs522.R;
import edu.stevens.cs522.sqs.CustomListActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.AdapterView.OnItemClickListener;

public class SqsQueueList extends CustomListActivity {
	
	protected List<String> queueListArray;
	
	
	private static final String SUCCESS = "Queue List";
	
	private Runnable postResults = new Runnable(){
		public void run(){
			updateUi(queueListArray, SUCCESS);
		}
	};


	private List<String> queueUrlListArray;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        startPopulateList();
        
        EditText messageInput = (EditText) findViewById(R.id.sqs_send_message_input);
        Button submitButton = (Button) findViewById(R.id.sqs_send_submit_button);
        View text = findViewById(R.id.sqs_send_message_intro_text);
        
        messageInput.setVisibility(View.INVISIBLE);
        submitButton.setVisibility(View.INVISIBLE);
        text.setVisibility(View.INVISIBLE);
    }
    
    protected void obtainListItems(){
    	//lwb 
    	queueListArray = new ArrayList<String>();
		queueUrlListArray = SimpleQueue.getQueueUrls();
		for (String s : queueUrlListArray) {
			queueListArray.add(s.substring(s.lastIndexOf("/")+1, s.length()));
		}
		getHandler().post(postResults);
    }
    
	protected void wireOnListClick(){
		getItemList().setOnItemClickListener(new OnItemClickListener() {
		    public void onItemClick(AdapterView<?> list, View view, int position, long id) {
		    	final String queueUrl = ((TextView)view).getText().toString();
				Intent sqsRecieveIntent = new Intent(SqsQueueList.this, SqsRecieveMessages.class);
				sqsRecieveIntent.putExtra( SimpleQueue.QUEUE_URL, queueUrlListArray.get(position) );
				startActivity(sqsRecieveIntent);	    
			}
		 });
	}

}
