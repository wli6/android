/*
 * Copyright 2010-2012 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 *
 *  http://aws.amazon.com/apache2.0
 *
 * or in the "license" file accompanying this file. This file is distributed
 * on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */
package edu.stevens.cs522.sqs.util;

import java.util.ArrayList;
import java.util.List;

import edu.stevens.cs522.R;
import edu.stevens.cs522.sqs.CustomListActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Toast;

public class SqsRecieveMessages extends CustomListActivity {
	
	protected List<String> queueMessageArray;
	private String queueUrl;
	
	ArrayAdapter<String> messages;
	
	private static final String SUCCESS = "Recieved Messages";
	
	
	private Runnable postResults = new Runnable(){
		public void run(){
			updateUi(queueMessageArray, SUCCESS, CustomListActivity.LEFT);
		}
	};
	private EditText messageInput;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mHandler = new Handler();
        Bundle extras = this.getIntent().getExtras();
        queueUrl = extras.getString(SimpleQueue.QUEUE_URL);
        startPopulateList();
        View titleTextView = findViewById(R.id.sqs_send_message_intro_text);
         
        messageInput = (EditText) findViewById(R.id.sqs_send_message_input);
        Button submitButton = (Button) findViewById(R.id.sqs_send_submit_button);
        
        submitButton.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {	try {
				SimpleQueue.sendMessage(queueUrl, messageInput.getText().toString());
				finish();
			} catch (Throwable e) {
				setStackAndPost(e);
			}}
		});
    }
    
    protected void obtainListItems(){    	
    	queueMessageArray  = new ArrayList<String>(); 
    	List<String> tempQueueMessageArray = SimpleQueue.recieveMessageIds(queueUrl);
		int i = 0;
		for (String s : tempQueueMessageArray) {
			
			String message = SimpleQueue.getMessageBody(i++);
			queueMessageArray.add(message);
			
		}
		
		getHandler().post(postResults);
    }
    	
    @Override
    protected void wireOnListClick(){
		getItemList().setOnItemClickListener(new OnItemClickListener() {
		    public void onItemClick(AdapterView<?> list, View view, int position, long id) {
		    	Toast.makeText(getApplicationContext(), queueMessageArray.get(position), Toast.LENGTH_LONG).show();;
//				Intent messageBodyIntent = new Intent(SqsRecieveMessages.this, SqsMessageBody.class);
//				messageBodyIntent.putExtra( SimpleQueue.MESSAGE_INDEX, position );
//				messageBodyIntent.putExtra( SimpleQueue.MESSAGE_ID, queueMessageArray.get(position));
//				startActivity(messageBodyIntent);
		    }
		 });
    }
    
    
}
