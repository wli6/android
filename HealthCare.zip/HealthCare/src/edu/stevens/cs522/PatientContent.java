
package edu.stevens.cs522;

import android.net.Uri;
import android.provider.BaseColumns;
 
public class PatientContent {
	
	public static final String AUTHORITY = "patients";
 

	public static final class Location implements BaseColumns {
		
		/**
		 * Content URI for location data
		 */
		public static final Uri CONTENT_URI = Uri.parse("content://"+ AUTHORITY+"/location");
		
		/**
         * The MIME type of {@link #CONTENT_URI} providing a directory of notes.
         */
        public static final String CONTENT_TYPE = "vnd.android.cursor.dir/vnd.stevens.cs.cs522.patient";

        /**
         * The MIME type of a {@link #CONTENT_URI} sub-directory of a single note.
         */
        public static final String CONTENT_ITEM_TYPE = "vnd.android.cursor.item/vnd.stevens.cs.cs522.patient";

	
		public static final String DEFAULT_SORT_ORDER = "_id ASC";
	 
	
		/**
		 * Cross referenced ID in the Contacts Provider for more information
		 */
		public static final String ID = "id";
		
		public static final String NAME = "name";
 
		/**
		 * latitude coordinate
		 */
		public static final String LATITUDE = "latitude";
	
		/**
		 * longitude coordinate
		 */
		public static final String LONGITUDE = "longitude";

		/**
		 * TO SEE OR NOT
		 */
		public static final String TOBEVISITED  = "toBeVisited";

		public static final String ADDRESS = "address";
	}
}
